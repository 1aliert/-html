// This file contains the JavaScript code for the e-commerce website.

// القائمة الجانبية
const sideMenuBtn = document.getElementById('sideMenuBtn');
const sideMenu = document.getElementById('sideMenu');
const closeSideMenu = document.getElementById('closeSideMenu');

sideMenuBtn.onclick = function() {
    sideMenu.style.left = '0';
    document.body.classList.add('body-shift');
};
closeSideMenu.onclick = function() {
    sideMenu.style.left = '';
    document.body.classList.remove('body-shift');
};
window.addEventListener('click', function(e) {
    var menu = document.getElementById('sideMenu');
    var btn = document.getElementById('sideMenuBtn');
    if (menu.style.left === '0px' && !menu.contains(e.target) && e.target !== btn) {
        menu.style.left = '-260px';
    }
});
document.querySelectorAll('.side-link').forEach(link => {
    link.addEventListener('click', function() {
        document.getElementById('sideMenu').style.left = '';
        document.body.classList.remove('body-shift');
    });
});

// البحث
document.addEventListener('DOMContentLoaded', function() {
    var searchBtn = document.querySelector('.search-bar button');
    var searchInput = document.querySelector('.search-bar input');
    if (searchBtn && searchInput) {
        searchBtn.addEventListener('click', function() {
            var query = searchInput.value.trim();
            if (query) {
                alert('نتيجة البحث عن: ' + query);
            } else {
                alert('يرجى إدخال كلمة للبحث');
            }
        });
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                searchBtn.click();
            }
        });
    }
});

// عربة التسوق
let cart = JSON.parse(localStorage.getItem('cart')) || [];

function showToast(message, type = "info") {
    let toast = document.createElement('div');
    toast.textContent = message;
    toast.style.position = 'fixed';
    toast.style.bottom = '30px';
    toast.style.left = '50%';
    toast.style.transform = 'translateX(-50%)';
    toast.style.background = type === "success" ? "#4caf50" : "#f8b500";
    toast.style.color = "#fff";
    toast.style.padding = '12px 28px';
    toast.style.borderRadius = '8px';
    toast.style.fontSize = '1.1em';
    toast.style.zIndex = 9999;
    toast.style.boxShadow = "0 2px 8px #0002";
    document.body.appendChild(toast);
    setTimeout(() => { toast.remove(); }, 1800);
}

function addToCart(productName, price) {
    const existing = cart.find(item => item.name === productName);
    let productElem = Array.from(document.querySelectorAll('.product h3')).find(h3 => h3.textContent === productName);
    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({ name: productName, price: price, quantity: 1 });
    }
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCart();
    showToast("تمت إضافة المنتج إلى العربة", "success");
    // تأثير وميض للمنتج
    if (productElem) {
        productElem.parentElement.classList.add('added-flash');
        setTimeout(() => productElem.parentElement.classList.remove('added-flash'), 700);
    }
}

function updateCart() {
    document.querySelector('.cart-count').textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
    var cartItems = document.getElementById('cartItems');
    if (cartItems) {
        cartItems.innerHTML = '';
        cart.forEach(function(item, i) {
            var li = document.createElement('li');
            li.innerHTML = `${item.name} - ${item.price} ريال × ${item.quantity}`;
            cartItems.appendChild(li);
        });
    }
}
function clearCart() {
    cart = [];
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCart();
    showToast("تم إفراغ العربة");
}
function showCheckout() {
    let summary = '<ul style="text-align:right">';
    let total = 0;
    cart.forEach(item => {
        summary += `<li>${item.name} - ${item.price} ريال × ${item.quantity}</li>`;
        total += item.price * item.quantity;
    });
    summary += `</ul><hr><strong>الإجمالي: ${total} ريال</strong>`;
    document.getElementById('orderSummary').innerHTML = summary;
    document.getElementById('checkoutSection').style.display = 'block';
}

function hideCheckout() {
    document.getElementById('checkoutSection').style.display = 'none';
    showToast("شكراً لتسوقك معنا!", "success");
    location.hash = "#payment";
    // صوت بسيط عند الشراء (اختياري)
    // new Audio('success.mp3').play();
}

function payOnDelivery() {
    hideCheckout();
    setTimeout(() => {
        alert("تم استلام طلبك بنجاح! سيتم التواصل معك لتأكيد الطلب والدفع عند الاستلام.");
    }, 400);
}

window.onload = function() {
    updateCart();
};

// تحسين البحث ليضيء المنتج عند العثور عليه
document.addEventListener('DOMContentLoaded', function() {
    var searchBtn = document.querySelector('.search-bar button');
    var searchInput = document.querySelector('.search-bar input');
    if (searchBtn && searchInput) {
        searchBtn.addEventListener('click', function() {
            var query = searchInput.value.trim();
            if (!query) {
                showToast('يرجى إدخال كلمة للبحث');
                return;
            }
            // البحث في الأقسام
            const sections = [
                { id: "perfumes", keywords: ["عطور", "عطر"] },
                { id: "incense", keywords: ["بخور"] },
                { id: "khamriyat", keywords: ["خمرية", "خمريات"] },
                { id: "spray", keywords: ["رشوش", "رشوشات"] },
                { id: "cart", keywords: ["عربة", "سلة", "التسوق"] },
                { id: "login", keywords: ["دخول", "تسجيل"] },
                { id: "payment", keywords: ["دفع", "وسائل الدفع"] },
                { id: "home", keywords: ["الرئيسية", "الصفحة الرئيسية"] }
            ];
            let found = sections.find(sec =>
                sec.keywords.some(word => query.includes(word))
            );
            if (found) {
                location.hash = "#" + found.id;
                showToast("تم الانتقال إلى القسم المطلوب", "success");
            } else {
                // البحث عن منتج
                const products = document.querySelectorAll('.product h3');
                let matched = false;
                for (let p of products) {
                    if (p.textContent.includes(query)) {
                        p.scrollIntoView({ behavior: "smooth", block: "center" });
                        p.parentElement.style.background = "#fff8e1";
                        setTimeout(() => p.parentElement.style.background = "", 1200);
                        showToast("تم العثور على المنتج", "success");
                        matched = true;
                        break;
                    }
                }
                if (!matched) {
                    showToast("لم يتم العثور على القسم أو المنتج");
                }
            }
        });
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                searchBtn.click();
            }
        });
    }
});